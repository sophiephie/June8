package Activity2;

public class number2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(4.0 * (1 - (1.0/3) + (1.0/5) - (1.0/7) + (1.0/9) - (1.0/11)));

	}

}
