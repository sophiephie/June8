package Activity2;

public class number3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
				
		double radius = 7.5; 
		double pi = 3.14159;
		double num = 2;
		
		double dmult, dmult2;

		double perimeter = num * radius * pi; 
		double area = pi * (radius * radius);
		

		
		System.out.println("The perimeter of a circle is " + perimeter );
		System.out.println("The area of a circle is " + area );
		
		
		
		
				

	}

}
