package Activity2;

public class number5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		double width = 5.5;
		double height = 8.5;
		
		System.out.println("The area is " + (width * height));
		System.out.println("The perimeter is " + 2 * (width + height));
		
		

	}

}
