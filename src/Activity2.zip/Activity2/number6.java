package Activity2;

import java.util.Scanner;

public class number6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner kb = new Scanner(System.in);
		
		System.out.println("Input a number");
		int num;
		
		num = kb.nextInt();
		
		System.out.println(Integer.toBinaryString(num));		
		

	}

	}


