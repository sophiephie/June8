package Activity2;

public class number7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int myrandom1 = (int) (Math.random() *22)+1;
		int myrandom2 = (int) (Math.random() *22)+1;
		int myrandom3 = (int) (Math.random() *22)+1;
		int myrandom4 = (int) (Math.random() *22)+1;
		int myrandom5 = (int) (Math.random() *22)+1;
		int myrandom6 = (int) (Math.random() *22)+1;
		int myrandom7 = (int) (Math.random() *22)+1;
		int myrandom8 = (int) (Math.random() *22)+1;
		int myrandom9 = (int) (Math.random() *22)+1;
		int myrandom0 = (int) (Math.random() *22)+1;
	
		System.out.println(myrandom1);
		System.out.println(myrandom2);
		System.out.println(myrandom3);
		System.out.println(myrandom4);
		System.out.println(myrandom5);
		System.out.println(myrandom6);
		System.out.println(myrandom7);
		System.out.println(myrandom8);
		System.out.println(myrandom9);
		System.out.println(myrandom0);

	}

}
